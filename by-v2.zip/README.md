# Beyond Judgement - The Whisper Path

## Run in IntelliJ
1. Start MySQL (or XAMPP/MariaDB). Edit `db.properties` (user / password) if needed. The game creates the database and tables itself.
2. IntelliJ: File > Open > select `pom.xml` > "Open as Project". Wait for Maven to download the dependencies.
3. Run `src/main/java/game/Launcher.java` (the `main` method).
   Always run **Launcher**, not App (App gives "JavaFX runtime components are missing").
   Alternative: `mvn javafx:run`

## Where things are
- `src/main/java/game/`    Java backend (Bridge = what JavaScript may call, Db, Accounts, PlayerData, Audio)
- `src/main/resources/web/` HTML / CSS / JS (open `index.html` through a local web server to test the UI without Java; a fake bridge is used)
- `src/main/resources/story-line/` all story JSON + `README.txt` (how to add dialogue)
- `src/main/resources/img/`, `audio/`  art and sounds

BEYOND JUDGEMENT - The Whisper Path

RUN
1. Start MySQL (XAMPP / MySQL Server). Edit db.properties (user / password) if needed.
   The game creates the database "beyond_judgement" and all tables by itself.
2. Open this folder in IntelliJ IDEA, wait for Maven to download dependencies.
3. Run the class  game.Launcher  (src/main/java/game/Launcher.java).

FOLDERS
src/main/java/game            Java: window, bridge, MySQL, accounts, saves, audio
src/main/resources/web        HTML / CSS / JS (all screens and the visual-novel engine)
src/main/resources/story-line story JSON  (see README.txt inside to add dialogue)
src/main/resources/img        characters + backgrounds + evidence art
src/main/resources/audio      sounds

Front-end only preview (no Java/MySQL): open web/index.html in Chrome via a local server
(e.g. VS Code "Live Server" on src/main/resources). A fake in-browser database is used.

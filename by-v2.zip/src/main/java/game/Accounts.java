package game;

import org.mindrot.jbcrypt.BCrypt;

import java.sql.*;
import java.util.*;
import java.util.regex.Pattern;

/** Create / login / delete accounts. Passwords are stored as BCrypt hashes only. Max 3 accounts. */
public final class Accounts {
    public static final int MAX_ACCOUNTS = 3;
    private static final Pattern NAME = Pattern.compile("^[\\p{L}\\p{N}_ -]{3,20}$");

    private Accounts() {}

    public static Map<String, Object> list() {
        String sql = "SELECT p.username, p.last_login, " +
                "(SELECT COALESCE(MAX(g.completed),0) FROM player_progress g WHERE g.player_id=p.player_id AND g.case_id='case1') AS done " +
                "FROM players p ORDER BY p.player_id";
        try (Connection c = Db.conn(); Statement st = c.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            List<Map<String, Object>> rows = new ArrayList<>();
            while (rs.next()) {
                Map<String, Object> a = new LinkedHashMap<>();
                a.put("name", rs.getString(1));
                Timestamp ts = rs.getTimestamp(2);
                String last = ts == null ? "" : ts.toLocalDateTime().toString().replace('T', ' ');
                a.put("last", last.length() > 16 ? last.substring(0, 16) : last);
                a.put("case1Done", rs.getInt(3) > 0);
                rows.add(a);
            }
            Map<String, Object> r = R.ok();
            r.put("accounts", rows);
            r.put("max", MAX_ACCOUNTS);
            return r;
        } catch (SQLException e) {
            Db.log(e);
            return R.err("err.db");
        }
    }

    /** On success the map contains "id" (kept inside Java, removed before sending to JS). */
    public static Map<String, Object> register(String name, String pw, String pw2) {
        name = name == null ? "" : name.trim();
        if (!NAME.matcher(name).matches()) return R.err("err.name_invalid");
        if (pw == null || pw.length() < 4 || pw.length() > 50) return R.err("err.pw_short");
        if (!pw.equals(pw2)) return R.err("err.pw_mismatch");
        try (Connection c = Db.conn()) {
            try (PreparedStatement ps = c.prepareStatement("SELECT COUNT(*) FROM players");
                 ResultSet rs = ps.executeQuery()) {
                rs.next();
                if (rs.getInt(1) >= MAX_ACCOUNTS) return R.err("err.limit");
            }
            try (PreparedStatement ps = c.prepareStatement("SELECT 1 FROM players WHERE username=?")) {
                ps.setString(1, name);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) return R.err("err.name_taken");
                }
            }
            String hash = BCrypt.hashpw(pw, BCrypt.gensalt(10));
            try (PreparedStatement ps = c.prepareStatement(
                    "INSERT INTO players(username, password_hash, last_login) VALUES(?,?,NOW())", Statement.RETURN_GENERATED_KEYS)) {
                ps.setString(1, name);
                ps.setString(2, hash);
                ps.executeUpdate();
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    keys.next();
                    Map<String, Object> r = R.ok();
                    r.put("id", keys.getInt(1));
                    r.put("name", name);
                    return r;
                }
            }
        } catch (SQLException e) {
            Db.log(e);
            return R.err("err.db");
        }
    }

    public static Map<String, Object> login(String name, String pw) {
        name = name == null ? "" : name.trim();
        if (name.isEmpty() || pw == null || pw.isEmpty()) return R.err("err.bad_login");
        try (Connection c = Db.conn();
             PreparedStatement ps = c.prepareStatement("SELECT player_id, username, password_hash FROM players WHERE username=?")) {
            ps.setString(1, name);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return R.err("err.bad_login");
                if (!checkPw(pw, rs.getString(3))) return R.err("err.bad_login");
                int id = rs.getInt(1);
                try (PreparedStatement up = c.prepareStatement("UPDATE players SET last_login=NOW() WHERE player_id=?")) {
                    up.setInt(1, id);
                    up.executeUpdate();
                }
                Map<String, Object> r = R.ok();
                r.put("id", id);
                r.put("name", rs.getString(2));
                return r;
            }
        } catch (SQLException e) {
            Db.log(e);
            return R.err("err.db");
        }
    }

    /** Deletes the account (and, through ON DELETE CASCADE, all of its data). */
    public static Map<String, Object> delete(String name, String pw) {
        Map<String, Object> r = login(name, pw);
        if (!Boolean.TRUE.equals(r.get("ok"))) return r;
        int id = (Integer) r.get("id");
        try (Connection c = Db.conn(); PreparedStatement ps = c.prepareStatement("DELETE FROM players WHERE player_id=?")) {
            ps.setInt(1, id);
            ps.executeUpdate();
            Map<String, Object> ok = R.ok();
            ok.put("id", id);
            return ok;
        } catch (SQLException e) {
            Db.log(e);
            return R.err("err.db");
        }
    }

    private static boolean checkPw(String pw, String hash) {
        try {
            return BCrypt.checkpw(pw, hash);
        } catch (IllegalArgumentException e) {
            return false;
        }
    }
}

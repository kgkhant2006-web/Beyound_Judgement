package game;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.concurrent.Worker;
import javafx.scene.Scene;
import javafx.scene.input.KeyCombination;
import javafx.scene.paint.Color;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Stage;
import netscape.javascript.JSObject;

/** JavaFX window that hosts the HTML/CSS/JS game inside a WebView. */
public class App extends Application {
    private static Bridge bridge;   // static = never garbage collected while the page uses it
    private Stage stage;
    private WebEngine engine;

    @Override
    public void start(Stage stage) {
        this.stage = stage;
        Db.init();   // never throws; the login screen shows the error and a Retry button

        WebView view = new WebView();
        view.setContextMenuEnabled(false);
        engine = view.getEngine();
        engine.setUserAgent(engine.getUserAgent() + " BJFX");   // lets the page know it runs inside the game
        bridge = new Bridge(this);

        engine.getLoadWorker().stateProperty().addListener((obs, old, state) -> {
            if (state == Worker.State.SUCCEEDED) {
                JSObject window = (JSObject) engine.executeScript("window");
                window.setMember("jb", bridge);
                engine.executeScript("BJ.start()");
            } else if (state == Worker.State.FAILED) {
                System.err.println("[App] Could not load the page: " + engine.getLoadWorker().getException());
            }
        });
        engine.load(App.class.getResource("/web/index.html").toExternalForm());

        stage.setTitle("Beyond Judgement - The Whisper Path");
        stage.setScene(new Scene(view, 1280, 720, Color.BLACK));
        stage.setMinWidth(960);
        stage.setMinHeight(560);
        stage.setFullScreenExitHint("");
        stage.setFullScreenExitKeyCombination(KeyCombination.NO_MATCH);   // ESC is used for the pause menu
        stage.setOnCloseRequest(e -> {
            e.consume();
            quit();
        });
        stage.show();
    }

    public void setFullscreen(boolean on) {
        stage.setFullScreen(on);
    }

    /** Autosave, stop sounds, close. */
    public void quit() {
        try {
            engine.executeScript("window.BJ && BJ.saveNow && BJ.saveNow()");
        } catch (Exception ignored) {
        }
        if (bridge != null) bridge.shutdown();
        Platform.exit();
        System.exit(0);
    }

    public static void main(String[] args) {
        launch(args);
    }
}

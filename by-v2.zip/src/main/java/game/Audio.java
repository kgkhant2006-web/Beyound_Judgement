package game;

import javafx.scene.media.AudioClip;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

import java.io.InputStream;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

/** Sound effects (cached once) + one looping background track. Files live in resources/audio/*.wav */
public final class Audio {
    private static final Pattern SAFE = Pattern.compile("[a-z0-9_-]+");
    private final Map<String, AudioClip> clips = new HashMap<>();
    private final Map<String, String> uris = new HashMap<>();
    private MediaPlayer music;
    private String musicName = "";
    private double master = 0.8, musicVol = 0.5, sfxVol = 0.7;

    public void setVolumes(double m, double mu, double s) {
        master = clamp(m);
        musicVol = clamp(mu);
        sfxVol = clamp(s);
        if (music != null) music.setVolume(master * musicVol);
    }

    public void sfx(String name) {
        try {
            if (name == null || !SAFE.matcher(name).matches()) return;
            AudioClip clip = clips.get(name);
            if (clip == null) {
                String uri = uri(name);
                if (uri == null) return;
                clip = new AudioClip(uri);
                clips.put(name, clip);
            }
            clip.play(master * sfxVol);
        } catch (Throwable t) {
            System.err.println("[Audio] " + t);
        }
    }

    public void playMusic(String name) {
        try {
            if (name == null || !SAFE.matcher(name).matches()) return;
            if (name.equals(musicName) && music != null) return;
            stopMusic();
            String uri = uri(name);
            if (uri == null) return;
            music = new MediaPlayer(new Media(uri));
            music.setCycleCount(MediaPlayer.INDEFINITE);
            music.setVolume(master * musicVol);
            music.play();
            musicName = name;
        } catch (Throwable t) {
            System.err.println("[Audio] " + t);
        }
    }

    public void stopMusic() {
        if (music != null) {
            music.stop();
            music.dispose();
            music = null;
        }
        musicName = "";
    }

    public void shutdown() {
        stopMusic();
    }

    private String uri(String name) {
        String cached = uris.get(name);
        if (cached != null) return cached;
        try {
            URL u = Audio.class.getResource("/audio/" + name + ".wav");
            if (u == null) return null;
            String result;
            if ("file".equals(u.getProtocol())) {
                result = u.toExternalForm();
            } else { // running from a jar: copy to a temp file once
                Path tmp = Files.createTempFile("bj-" + name + "-", ".wav");
                tmp.toFile().deleteOnExit();
                try (InputStream in = u.openStream()) {
                    Files.copy(in, tmp, StandardCopyOption.REPLACE_EXISTING);
                }
                result = tmp.toUri().toString();
            }
            uris.put(name, result);
            return result;
        } catch (Exception e) {
            System.err.println("[Audio] " + e);
            return null;
        }
    }

    private static double clamp(double v) {
        return Math.max(0, Math.min(1, v));
    }
}

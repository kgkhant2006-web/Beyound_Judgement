package game;

import com.google.gson.Gson;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.prefs.Preferences;

/**
 * The ONLY object JavaScript can talk to (window.jb). Every method returns a JSON string.
 * JavaScript never sends a player id: Java remembers who is logged in.
 */
public class Bridge {
    private static final Gson GSON = new Gson();
    private final App app;
    private final Audio audio = new Audio();
    private int playerId = 0;
    private String playerName = "";

    public Bridge(App app) {
        this.app = app;
    }

    // ------------------------------------------------------------ system
    public String status() {
        Map<String, Object> r = R.ok();
        r.put("db", Db.isReady());
        r.put("error", Db.lastError());
        return json(r);
    }

    public String retryDb() {
        Db.init();
        return status();
    }

    public String readResource(String path) {
        try {
            if (path == null || path.contains("..") || !(path.startsWith("story-line/") || path.startsWith("lang/"))) return "";
            try (InputStream in = Bridge.class.getResourceAsStream("/" + path)) {
                return in == null ? "" : new String(in.readAllBytes(), StandardCharsets.UTF_8);
            }
        } catch (Exception e) {
            return "";
        }
    }

    public void log(String msg) {
        System.out.println("[JS] " + msg);
    }

    public void exitGame() {
        app.quit();
    }

    public void setFullscreen(String on) {
        app.setFullscreen("true".equals(on));
    }

    public String getLang() {
        return Preferences.userNodeForPackage(Bridge.class).get("lang", "en");
    }

    public void setLang(String lang) {
        if ("en".equals(lang) || "my".equals(lang) || "ja".equals(lang)) {
            Preferences.userNodeForPackage(Bridge.class).put("lang", lang);
        }
    }

    // ------------------------------------------------------------ accounts
    public String listAccounts() {
        return json(Accounts.list());
    }

    public String register(String name, String pw, String pw2) {
        return json(startSession(Accounts.register(name, pw, pw2)));
    }

    public String login(String name, String pw) {
        return json(startSession(Accounts.login(name, pw)));
    }

    public String logout() {
        playerId = 0;
        playerName = "";
        audio.stopMusic();
        return json(R.ok());
    }

    public String deleteAccount(String name, String pw) {
        Map<String, Object> r = Accounts.delete(name, pw);
        if (Boolean.TRUE.equals(r.get("ok"))) {
            if ((Integer) r.get("id") == playerId) logout();
            r.remove("id");
        }
        return json(r);
    }

    public String me() {
        Map<String, Object> r = playerId > 0 ? R.ok() : R.err("err.no_session");
        r.put("name", playerName);
        return json(r);
    }

    // ------------------------------------------------------------ progress
    public String getProgress() {
        return json(need() ? PlayerData.progress(playerId) : R.err("err.no_session"));
    }

    public String startCase(String caseId) {
        return json(need() ? PlayerData.startCase(playerId, safe(caseId)) : R.err("err.no_session"));
    }

    public String saveState(String caseId, String stateJson) {
        return json(need() ? PlayerData.saveState(playerId, safe(caseId), stateJson) : R.err("err.no_session"));
    }

    public String loadState(String caseId) {
        return json(need() ? PlayerData.loadState(playerId, safe(caseId)) : R.err("err.no_session"));
    }

    public String completeCase(String caseId) {
        return json(need() ? PlayerData.completeCase(playerId, safe(caseId)) : R.err("err.no_session"));
    }

    // ------------------------------------------------------------ evidence / notebook / notes / settings
    public String collectEvidence(String id, String caseId) {
        return json(need() ? PlayerData.collect(playerId, "player_evidence", "evidence_id", safe(id), safe(caseId)) : R.err("err.no_session"));
    }

    public String listEvidence() {
        return json(need() ? PlayerData.listIds(playerId, "player_evidence", "evidence_id", "collected_at") : R.err("err.no_session"));
    }

    public String addNotebook(String id, String caseId) {
        return json(need() ? PlayerData.collect(playerId, "player_notebook", "entry_id", safe(id), safe(caseId)) : R.err("err.no_session"));
    }

    public String listNotebook() {
        return json(need() ? PlayerData.listIds(playerId, "player_notebook", "entry_id", "added_at") : R.err("err.no_session"));
    }

    public String listNotes() {
        return json(need() ? PlayerData.listNotes(playerId) : R.err("err.no_session"));
    }

    public String saveNote(String id, String title, String content) {
        return json(need() ? PlayerData.saveNote(playerId, toInt(id), title, content) : R.err("err.no_session"));
    }

    public String deleteNote(String id) {
        return json(need() ? PlayerData.deleteNote(playerId, toInt(id)) : R.err("err.no_session"));
    }

    public String getSettings() {
        return json(need() ? PlayerData.getSettings(playerId) : R.err("err.no_session"));
    }

    public String saveSettings(String settingsJson) {
        return json(need() ? PlayerData.saveSettings(playerId, settingsJson) : R.err("err.no_session"));
    }

    // ------------------------------------------------------------ audio
    public void playSound(String name) {
        audio.sfx(name);
    }

    public void playMusic(String name) {
        audio.playMusic(name);
    }

    public void stopMusic() {
        audio.stopMusic();
    }

    public void setVolumes(String master, String music, String sfx) {
        audio.setVolumes(toInt(master) / 100.0, toInt(music) / 100.0, toInt(sfx) / 100.0);
    }

    public void shutdown() {
        audio.shutdown();
    }

    // ------------------------------------------------------------ helpers
    private Map<String, Object> startSession(Map<String, Object> r) {
        if (Boolean.TRUE.equals(r.get("ok"))) {
            playerId = (Integer) r.remove("id");
            playerName = (String) r.get("name");
        }
        return r;
    }

    private boolean need() {
        return playerId > 0 && Db.isReady();
    }

    private static String safe(String s) {
        return s == null ? "" : s.replaceAll("[^A-Za-z0-9_-]", "");
    }

    private static int toInt(String s) {
        try {
            return (int) Math.round(Double.parseDouble(s));
        } catch (Exception e) {
            return 0;
        }
    }

    private static String json(Object o) {
        return GSON.toJson(o);
    }
}

package game;

import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.util.regex.Pattern;

/** MySQL connection + automatic database/table creation. Only Java touches the database. */
public final class Db {
    private static String host = "localhost", port = "3306", database = "beyond_judgement", user = "root", password = "";
    private static boolean ready = false;
    private static String lastError = "";
    private static final String PARAMS = "?allowPublicKeyRetrieval=true&useSSL=false&serverTimezone=UTC&characterEncoding=UTF-8&connectTimeout=5000";

    private Db() {}

    public static boolean isReady() { return ready; }
    public static String lastError() { return lastError; }

    public static synchronized boolean init() {
        ready = false;
        lastError = "";
        try {
            loadConfig();
            if (!Pattern.matches("[A-Za-z0-9_]+", database)) {
                throw new IllegalArgumentException("Invalid database name in db.properties");
            }
            Class.forName("com.mysql.cj.jdbc.Driver");
            // 1) create the database when it does not exist
            try (Connection c = DriverManager.getConnection("jdbc:mysql://" + host + ":" + port + "/" + PARAMS, user, password);
                 Statement st = c.createStatement()) {
                st.executeUpdate("CREATE DATABASE IF NOT EXISTS `" + database + "` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            }
            // 2) create the tables
            try (Connection c = conn(); Statement st = c.createStatement()) {
                for (String sql : SCHEMA) st.executeUpdate(sql);
            }
            ready = true;
        } catch (Throwable t) {
            lastError = t.getMessage() == null ? t.toString() : t.getMessage();
            System.err.println("[DB] " + lastError);
        }
        return ready;
    }

    public static Connection conn() throws SQLException {
        return DriverManager.getConnection("jdbc:mysql://" + host + ":" + port + "/" + database + PARAMS, user, password);
    }

    private static void loadConfig() {
        Properties p = new Properties();
        try (InputStream in = new FileInputStream("db.properties")) {   // next to the project / game
            p.load(in);
        } catch (Exception ignored) {
            System.err.println("[DB] db.properties not found, using defaults (root / no password)");
        }
        host = p.getProperty("host", host).trim();
        port = p.getProperty("port", port).trim();
        database = p.getProperty("database", database).trim();
        user = p.getProperty("user", user).trim();
        password = p.getProperty("password", password);
    }

    public static void log(Exception e) {
        System.err.println("[DB] " + e.getMessage());
    }

    private static final String[] SCHEMA = {
        "CREATE TABLE IF NOT EXISTS players (" +
            " player_id INT AUTO_INCREMENT PRIMARY KEY," +
            " username VARCHAR(32) NOT NULL UNIQUE," +
            " password_hash VARCHAR(100) NOT NULL," +
            " created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP," +
            " last_login TIMESTAMP NULL DEFAULT NULL" +
            ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS player_progress (" +
            " player_id INT NOT NULL," +
            " case_id VARCHAR(32) NOT NULL," +
            " completed TINYINT(1) NOT NULL DEFAULT 0," +
            " state_json MEDIUMTEXT NULL," +
            " updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP," +
            " PRIMARY KEY (player_id, case_id)," +
            " FOREIGN KEY (player_id) REFERENCES players(player_id) ON DELETE CASCADE" +
            ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS player_evidence (" +
            " player_id INT NOT NULL," +
            " evidence_id VARCHAR(48) NOT NULL," +
            " case_id VARCHAR(32) NOT NULL," +
            " collected_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP," +
            " PRIMARY KEY (player_id, evidence_id)," +
            " FOREIGN KEY (player_id) REFERENCES players(player_id) ON DELETE CASCADE" +
            ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS player_notebook (" +
            " player_id INT NOT NULL," +
            " entry_id VARCHAR(48) NOT NULL," +
            " case_id VARCHAR(32) NOT NULL," +
            " added_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP," +
            " PRIMARY KEY (player_id, entry_id)," +
            " FOREIGN KEY (player_id) REFERENCES players(player_id) ON DELETE CASCADE" +
            ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS player_notes (" +
            " note_id INT AUTO_INCREMENT PRIMARY KEY," +
            " player_id INT NOT NULL," +
            " title VARCHAR(100) NOT NULL DEFAULT ''," +
            " content TEXT NULL," +
            " created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP," +
            " updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP," +
            " FOREIGN KEY (player_id) REFERENCES players(player_id) ON DELETE CASCADE" +
            ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS player_settings (" +
            " player_id INT NOT NULL PRIMARY KEY," +
            " settings_json TEXT NULL," +
            " FOREIGN KEY (player_id) REFERENCES players(player_id) ON DELETE CASCADE" +
            ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    };
}

package game;

/** Real entry point. It must NOT extend Application, otherwise IntelliJ says "JavaFX runtime components are missing". */
public class Launcher {
    public static void main(String[] args) {
        App.main(args);
    }
}

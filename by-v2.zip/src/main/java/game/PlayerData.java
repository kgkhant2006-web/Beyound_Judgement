package game;

import java.sql.*;
import java.util.*;

/** Everything that belongs to one player: progress/autosave, evidence, notebook records, notes, settings. */
public final class PlayerData {
    private PlayerData() {}

    // ---------------------------------------------------------------- progress / autosave
    public static Map<String, Object> progress(int pid) {
        try (Connection c = Db.conn();
             PreparedStatement ps = c.prepareStatement(
                     "SELECT case_id, completed, (state_json IS NOT NULL) FROM player_progress WHERE player_id=?")) {
            ps.setInt(1, pid);
            Map<String, Object> cases = new LinkedHashMap<>();
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Map<String, Object> one = new LinkedHashMap<>();
                    one.put("completed", rs.getInt(2) > 0);
                    one.put("hasSave", rs.getInt(3) > 0);
                    cases.put(rs.getString(1), one);
                }
            }
            Map<String, Object> r = R.ok();
            r.put("cases", cases);
            return r;
        } catch (SQLException e) {
            Db.log(e);
            return R.err("err.db");
        }
    }

    /** New game / replay: wipes the save, evidence and notebook of this case. "completed" is kept. */
    public static Map<String, Object> startCase(int pid, String caseId) {
        try (Connection c = Db.conn()) {
            ensureRow(c, pid, caseId);
            exec(c, "UPDATE player_progress SET state_json=NULL WHERE player_id=? AND case_id=?", pid, caseId);
            exec(c, "DELETE FROM player_evidence WHERE player_id=? AND case_id=?", pid, caseId);
            exec(c, "DELETE FROM player_notebook WHERE player_id=? AND case_id=?", pid, caseId);
            return R.ok();
        } catch (SQLException e) {
            Db.log(e);
            return R.err("err.db");
        }
    }

    public static Map<String, Object> saveState(int pid, String caseId, String json) {
        try (Connection c = Db.conn()) {
            ensureRow(c, pid, caseId);
            try (PreparedStatement ps = c.prepareStatement("UPDATE player_progress SET state_json=? WHERE player_id=? AND case_id=?")) {
                ps.setString(1, json);
                ps.setInt(2, pid);
                ps.setString(3, caseId);
                ps.executeUpdate();
            }
            return R.ok();
        } catch (SQLException e) {
            Db.log(e);
            return R.err("err.db");
        }
    }

    public static Map<String, Object> loadState(int pid, String caseId) {
        try (Connection c = Db.conn();
             PreparedStatement ps = c.prepareStatement("SELECT state_json FROM player_progress WHERE player_id=? AND case_id=?")) {
            ps.setInt(1, pid);
            ps.setString(2, caseId);
            try (ResultSet rs = ps.executeQuery()) {
                Map<String, Object> r = R.ok();
                r.put("state", rs.next() ? rs.getString(1) : null);
                return r;
            }
        } catch (SQLException e) {
            Db.log(e);
            return R.err("err.db");
        }
    }

    public static Map<String, Object> completeCase(int pid, String caseId) {
        try (Connection c = Db.conn()) {
            ensureRow(c, pid, caseId);
            exec(c, "UPDATE player_progress SET completed=1, state_json=NULL WHERE player_id=? AND case_id=?", pid, caseId);
            return R.ok();
        } catch (SQLException e) {
            Db.log(e);
            return R.err("err.db");
        }
    }

    // ---------------------------------------------------------------- evidence + notebook records
    public static Map<String, Object> collect(int pid, String table, String column, String id, String caseId) {
        // table/column are chosen by Bridge (never from JS), so concatenation is safe here
        try (Connection c = Db.conn();
             PreparedStatement ps = c.prepareStatement("INSERT IGNORE INTO " + table + "(player_id, " + column + ", case_id) VALUES(?,?,?)")) {
            ps.setInt(1, pid);
            ps.setString(2, id);
            ps.setString(3, caseId);
            int n = ps.executeUpdate();
            Map<String, Object> r = R.ok();
            r.put("isNew", n > 0);
            return r;
        } catch (SQLException e) {
            Db.log(e);
            return R.err("err.db");
        }
    }

    public static Map<String, Object> listIds(int pid, String table, String column, String timeCol) {
        try (Connection c = Db.conn();
             PreparedStatement ps = c.prepareStatement("SELECT " + column + " FROM " + table + " WHERE player_id=? ORDER BY " + timeCol + ", " + column)) {
            ps.setInt(1, pid);
            List<String> ids = new ArrayList<>();
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) ids.add(rs.getString(1));
            }
            Map<String, Object> r = R.ok();
            r.put("ids", ids);
            return r;
        } catch (SQLException e) {
            Db.log(e);
            return R.err("err.db");
        }
    }

    // ---------------------------------------------------------------- player written notes
    public static Map<String, Object> listNotes(int pid) {
        try (Connection c = Db.conn();
             PreparedStatement ps = c.prepareStatement(
                     "SELECT note_id, title, content, updated_at FROM player_notes WHERE player_id=? ORDER BY updated_at DESC, note_id DESC")) {
            ps.setInt(1, pid);
            List<Map<String, Object>> rows = new ArrayList<>();
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Map<String, Object> n = new LinkedHashMap<>();
                    n.put("id", rs.getInt(1));
                    n.put("title", rs.getString(2));
                    n.put("content", rs.getString(3) == null ? "" : rs.getString(3));
                    Timestamp ts = rs.getTimestamp(4);
                    n.put("updated", ts == null ? "" : ts.toLocalDateTime().toString().replace('T', ' ').substring(0, 16));
                    rows.add(n);
                }
            }
            Map<String, Object> r = R.ok();
            r.put("notes", rows);
            return r;
        } catch (SQLException e) {
            Db.log(e);
            return R.err("err.db");
        }
    }

    /** noteId 0 = create a new note, otherwise update. Returns the note id. */
    public static Map<String, Object> saveNote(int pid, int noteId, String title, String content) {
        title = title == null ? "" : title.trim();
        if (title.length() > 100) title = title.substring(0, 100);
        content = content == null ? "" : content;
        if (content.length() > 5000) content = content.substring(0, 5000);
        try (Connection c = Db.conn()) {
            if (noteId <= 0) {
                try (PreparedStatement ps = c.prepareStatement(
                        "INSERT INTO player_notes(player_id, title, content) VALUES(?,?,?)", Statement.RETURN_GENERATED_KEYS)) {
                    ps.setInt(1, pid);
                    ps.setString(2, title);
                    ps.setString(3, content);
                    ps.executeUpdate();
                    try (ResultSet k = ps.getGeneratedKeys()) {
                        k.next();
                        Map<String, Object> r = R.ok();
                        r.put("id", k.getInt(1));
                        return r;
                    }
                }
            }
            try (PreparedStatement ps = c.prepareStatement(
                    "UPDATE player_notes SET title=?, content=? WHERE note_id=? AND player_id=?")) {
                ps.setString(1, title);
                ps.setString(2, content);
                ps.setInt(3, noteId);
                ps.setInt(4, pid);
                ps.executeUpdate();
                Map<String, Object> r = R.ok();
                r.put("id", noteId);
                return r;
            }
        } catch (SQLException e) {
            Db.log(e);
            return R.err("err.db");
        }
    }

    public static Map<String, Object> deleteNote(int pid, int noteId) {
        try (Connection c = Db.conn();
             PreparedStatement ps = c.prepareStatement("DELETE FROM player_notes WHERE note_id=? AND player_id=?")) {
            ps.setInt(1, noteId);
            ps.setInt(2, pid);
            ps.executeUpdate();
            return R.ok();
        } catch (SQLException e) {
            Db.log(e);
            return R.err("err.db");
        }
    }

    // ---------------------------------------------------------------- settings
    public static Map<String, Object> getSettings(int pid) {
        try (Connection c = Db.conn();
             PreparedStatement ps = c.prepareStatement("SELECT settings_json FROM player_settings WHERE player_id=?")) {
            ps.setInt(1, pid);
            try (ResultSet rs = ps.executeQuery()) {
                Map<String, Object> r = R.ok();
                r.put("settings", rs.next() ? rs.getString(1) : null);
                return r;
            }
        } catch (SQLException e) {
            Db.log(e);
            return R.err("err.db");
        }
    }

    public static Map<String, Object> saveSettings(int pid, String json) {
        try (Connection c = Db.conn()) {
            int n;
            try (PreparedStatement ps = c.prepareStatement("UPDATE player_settings SET settings_json=? WHERE player_id=?")) {
                ps.setString(1, json);
                ps.setInt(2, pid);
                n = ps.executeUpdate();
            }
            if (n == 0) {
                try (PreparedStatement ps = c.prepareStatement("INSERT IGNORE INTO player_settings(player_id, settings_json) VALUES(?,?)")) {
                    ps.setInt(1, pid);
                    ps.setString(2, json);
                    ps.executeUpdate();
                }
            }
            return R.ok();
        } catch (SQLException e) {
            Db.log(e);
            return R.err("err.db");
        }
    }

    // ---------------------------------------------------------------- helpers
    private static void ensureRow(Connection c, int pid, String caseId) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement("INSERT IGNORE INTO player_progress(player_id, case_id) VALUES(?,?)")) {
            ps.setInt(1, pid);
            ps.setString(2, caseId);
            ps.executeUpdate();
        }
    }

    private static void exec(Connection c, String sql, int pid, String caseId) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, pid);
            ps.setString(2, caseId);
            ps.executeUpdate();
        }
    }
}

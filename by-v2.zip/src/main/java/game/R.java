package game;

import java.util.LinkedHashMap;
import java.util.Map;

/** Tiny helper to build the JSON answers sent back to JavaScript. */
public final class R {
    private R() {}

    public static Map<String, Object> ok() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("ok", true);
        return m;
    }

    public static Map<String, Object> err(String key) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("ok", false);
        m.put("error", key);
        return m;
    }
}

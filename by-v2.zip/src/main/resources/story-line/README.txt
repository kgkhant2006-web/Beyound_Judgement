HOW TO ADD OR EDIT STORY  (no Java changes needed)

cases.json       list of cases + the chapter files each case plays, in order. "unlockedBy" = case that must be solved first.
characters.json  who can talk / appear (sprite = full body, head = portrait). Add a character here, then use its id in steps.
evidence.json    evidence items (image, name, description, info lines, optional "pages", optional "onCollect" steps).
notebook.json    notebook records shown as "NOTEBOOK UPDATE".
<chapter>.json   {"id":..., "music":"ambient", "steps":[ ... ]}

Every text can be {"my":"...","en":"...","ja":"..."}; a missing language falls back to my, then en.
Dialogue steps carry the languages directly: {"say":"police","my":"...","en":"...","ja":"..."}

STEP COMMANDS
{"bg":"toilet-3"}                          change background (file in img/, without .jpg; "black" = black)
{"show":"police","pos":"left|center|right"}   {"hide":"police"}   {"hideAll":1}
{"say":"detective","my":"..."}             character speaks (use "teacher" etc. for names without a sprite)
{"narr":1,"my":"..."}                      narration line
{"title":{"en":"Chapter 1","my":"..."},"sub":{...}}   black title card
{"label":"x"}   {"goto":"x"}   {"if":"flag","goto":"x"}   {"set":{"flag":true}}
{"choice":[{"my":"...","goto":"label","set":{"flag":1}}, ...]}
{"ask":{"title":{...},"topics":[{"id":"a1","q":{"my":"question"},"after":["a0"],"steps":[ ...answer steps... ]}]}}
      topic with "ev":"photo" = "Show evidence" button (needs that evidence; add "must":true to require it)
{"investigate":{"bg":"toilet-3","spots":[{"ev":"knife","x":62,"y":65,"w":11,"h":24,"after":"otherEvidenceId"}]}}
      x,y,w,h are percentages of the background. A spot with "container":true,"title":{...},"items":["id"] opens a bag.
{"gain":"record"}                          evidence popup that must be collected
{"nb":"nb-knife"}                          add + show a notebook record
{"deduce":{"need":3,"clues":[ids],"pairs":[{"a":"id","b":"id","lines":[steps]}]}}
{"accuse":{"suspects":[{"id":"nang","goto":"label","qs":{"my":[...]}}]}}
{"end":"win|lose|closed","bio":"kaung","retry":"label"}
{"sfx":"click|page|evidence|error"}   {"music":"ambient"}

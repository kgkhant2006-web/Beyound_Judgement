/* Thin wrapper around the Java bridge (window.jb). Every call returns a parsed object. */
var API = (function () {
  function j(s) {
    try { return JSON.parse(s); } catch (e) { return { ok: false, error: 'err.db' }; }
  }
  function s(v) { return v == null ? '' : String(v); }
  var B = function () { return window.jb; };
  return {
    status: function () { return j(B().status()); },
    retryDb: function () { return j(B().retryDb()); },
    readResource: function (p) { return B().readResource(p); },
    log: function (m) { try { B().log(s(m)); } catch (e) {} },
    exitGame: function () { B().exitGame(); },
    setFullscreen: function (on) { B().setFullscreen(on ? 'true' : 'false'); },
    getLang: function () { return s(B().getLang()); },
    setLang: function (l) { B().setLang(s(l)); },
    listAccounts: function () { return j(B().listAccounts()); },
    register: function (n, p, p2) { return j(B().register(s(n), s(p), s(p2))); },
    login: function (n, p) { return j(B().login(s(n), s(p))); },
    logout: function () { return j(B().logout()); },
    deleteAccount: function (n, p) { return j(B().deleteAccount(s(n), s(p))); },
    me: function () { return j(B().me()); },
    getProgress: function () { return j(B().getProgress()); },
    startCase: function (c) { return j(B().startCase(s(c))); },
    saveState: function (c, st) { return j(B().saveState(s(c), s(st))); },
    loadState: function (c) { return j(B().loadState(s(c))); },
    completeCase: function (c) { return j(B().completeCase(s(c))); },
    collectEvidence: function (id, c) { return j(B().collectEvidence(s(id), s(c))); },
    listEvidence: function () { return j(B().listEvidence()); },
    addNotebook: function (id, c) { return j(B().addNotebook(s(id), s(c))); },
    listNotebook: function () { return j(B().listNotebook()); },
    listNotes: function () { return j(B().listNotes()); },
    saveNote: function (id, t, c) { return j(B().saveNote(s(id), s(t), s(c))); },
    deleteNote: function (id) { return j(B().deleteNote(s(id))); },
    getSettings: function () { return j(B().getSettings()); },
    saveSettings: function (o) { return j(B().saveSettings(JSON.stringify(o))); },
    sound: function (n) { try { B().playSound(s(n)); } catch (e) {} },
    music: function (n) { try { B().playMusic(s(n)); } catch (e) {} },
    stopMusic: function () { try { B().stopMusic(); } catch (e) {} },
    volumes: function (m, mu, sf) { try { B().setVolumes(s(m), s(mu), s(sf)); } catch (e) {} }
  };
})();

/* Visual-novel engine. Reads chapter JSON (list of "steps") and plays them.
   A step is a small object, e.g. {"say":"police","my":"..."}, {"bg":"toilet-3"}, {"choice":[...]}.
   See story-line/README.txt for every command. */
var Engine = (function () {
  var t = I18N.t, L = I18N.L, $ = UI.$, el = UI.el;
  var def = null, chapters = [], st = null, frames = [];
  var advance = null, typing = null, curLine = null;
  var evList = [], nbList = [];
  var charEls = {}, ui = {}, bgFlip = 0, saveTimer = null, titleTimer = null, running = false, ended = false;

  // ---------------------------------------------------------------- start / stop
  function start(d, resume) {
    clearTimeout(titleTimer); clearTimeout(saveTimer);
    def = d; chapters = Story.loadCase(d); ended = false;
    var saved = null;
    if (resume) {
      var r = API.loadState(d.id);
      if (r.ok && r.state) { try { saved = JSON.parse(r.state); } catch (e) { saved = null; } }
    }
    if (!saved) API.startCase(d.id);
    st = saved || { ch: 0, i: 0, flags: {}, asked: {}, bg: '', chars: {}, music: '' };
    if (!chapters[st.ch]) { st.ch = 0; st.i = 0; }
    loadLists();
    charEls = {}; advance = null; typing = null; curLine = null;
    UI.show('game', buildGame);
    running = true;
    setBg(st.bg, true);
    for (var id in st.chars) showChar(id, st.chars[id], true);
    enterChapter(st.ch, st.i);
  }

  function stop() {
    running = false; clearTimeout(saveTimer); clearTimeout(titleTimer); stopTyping(); advance = null; frames = [];
    UI.closeAll();
  }

  function loadLists() {
    var r = API.listEvidence(); evList = r.ok ? r.ids.filter(function (id) { return Story.evidence[id]; }) : [];
    var n = API.listNotebook(); nbList = n.ok ? n.ids.filter(function (id) { return Story.notebook[id]; }) : [];
  }

  function buildGame(root) {
    root.appendChild(el(
      '<div class="game">' +
      '<div class="bg b1"></div><div class="bg b2"></div>' +
      '<div class="chars"></div><div class="spots"></div>' +
      '<div class="topbar"><div class="banner"></div><div class="tbtns"><button class="btn small" id="g-bag" data-i18n="game.bag"></button><button class="btn small" id="g-pause" data-i18n="game.pause"></button></div></div>' +
      '<div class="dlg"><img class="head" alt=""><div class="nameplate"></div><div class="txt"></div><div class="more">▼</div></div>' +
      '<div class="choices"></div><div class="askbox"></div><div class="titlecard"></div>' +
      '</div>'));
    var g = $('.game', root);
    ui = { game: g, b1: $('.b1', g), b2: $('.b2', g), chars: $('.chars', g), spots: $('.spots', g), banner: $('.banner', g),
      dlg: $('.dlg', g), head: $('.head', g), name: $('.nameplate', g), txt: $('.txt', g), more: $('.more', g),
      choices: $('.choices', g), ask: $('.askbox', g), title: $('.titlecard', g) };
    g.onclick = onClick;
    $('#g-bag', g).onclick = function (e) { e.stopPropagation(); UI.click(); UI.inventory(); };
    $('#g-pause', g).onclick = function (e) { e.stopPropagation(); UI.pause(); };
  }

  // ---------------------------------------------------------------- input
  function onClick() {
    if (!running || UI.hasOverlay()) return;
    if (typing) { finishTyping(); return; }
    if (advance) { var a = advance; advance = null; a(); }
  }
  function key(e) {   // called by main.js when no overlay is open
    if (!running || UI.screenName() !== 'game') return false;
    if (e.key === ' ' || e.key === 'Enter' || e.key === 'ArrowRight') { onClick(); return true; }
    if (e.key === 'Escape') { UI.pause(); return true; }
    if (e.key === 'i' || e.key === 'I') { UI.inventory(); return true; }
    return false;
  }

  // ---------------------------------------------------------------- saving
  function scheduleSave() { if (!running || ended) return; clearTimeout(saveTimer); saveTimer = setTimeout(saveNow, 500); }
  function saveNow() {
    if (!running || ended || !st || !def) return;
    clearTimeout(saveTimer);
    API.saveState(def.id, JSON.stringify(st));
  }

  // ---------------------------------------------------------------- main loop
  function enterChapter(ci, i) {
    st.ch = ci;
    frames = [{ steps: chapters[ci].steps, i: i || 0, base: true }];
    if (chapters[ci].music) API.music(chapters[ci].music);
    next();
  }

  function next() {
    if (!running) return;
    while (true) {
      var f = frames[frames.length - 1];
      if (!f) return;
      if (f.i >= f.steps.length) {
        frames.pop();
        if (!frames.length) { chapterEnd(); return; }
        if (f.onEnd) { f.onEnd(); return; }
        continue;
      }
      var idx = f.i, step = f.steps[idx];
      f.i++;
      if (f.base) { st.i = idx; scheduleSave(); }
      var blocked;
      try { blocked = run(step, idx); } catch (e) { API.log('Step error: ' + e.message + ' ' + JSON.stringify(step)); blocked = false; }
      if (blocked) return;
    }
  }

  function chapterEnd() {
    if (st.ch + 1 >= chapters.length) { stop(); UI.cases(); return; }
    st.ch++; st.i = 0;
    enterChapter(st.ch, 0);
  }

  function jump(label) {
    var base = frames[0];
    for (var k = 0; k < base.steps.length; k++) {
      if (base.steps[k].label === label) { frames = [base]; base.i = k; return true; }
    }
    API.log('Label not found: ' + label);
    return false;
  }

  /** Runs one step. Returns true when the engine has to wait for the player. */
  function run(s, idx) {
    if (s.bg !== undefined) { setBg(s.bg); return false; }
    if (s.show) { showChar(s.show, s.pos || 'center'); return false; }
    if (s.hide) { hideChar(s.hide); return false; }
    if (s.hideAll) { for (var id in charEls) hideChar(id); return false; }
    if (s.say !== undefined || s.narr) { say(s); return true; }
    if (s.title) { titleCard(s); return true; }
    if (s.label) return false;
    if (s.if) { if (st.flags[s.if]) jump(s.goto); return false; }
    if (s.goto) { jump(s.goto); return false; }
    if (s.set) { for (var k in s.set) st.flags[k] = s.set[k]; return false; }
    if (s.sfx) { API.sound(s.sfx); return false; }
    if (s.music) { API.music(s.music); return false; }
    if (s.nb) return notebookCard(s.nb);
    if (s.gain) return gain(s.gain);
    if (s.choice) { choice(s); return true; }
    if (s.ask) { showAsk(s, idx); return true; }
    if (s.investigate) { investigate(s.investigate); return true; }
    if (s.deduce) { deduce(s.deduce, idx); return true; }
    if (s.accuse) { accuse(s.accuse); return true; }
    if (s.end) { endScreen(s); return true; }
    return false;
  }

  // ---------------------------------------------------------------- background + characters
  function setBg(name, instant) {
    if (name === undefined) return;
    st.bg = name;
    var a = bgFlip ? ui.b2 : ui.b1, b = bgFlip ? ui.b1 : ui.b2;
    a.style.backgroundImage = (!name || name === 'black') ? 'none' : "url('../img/" + name + ".jpg')";
    a.className = 'bg on top' + (instant ? ' nt' : '');
    b.className = 'bg on' + (instant ? ' nt' : '');
    setTimeout(function () { b.className = 'bg nt'; }, instant ? 0 : 800);
    bgFlip = 1 - bgFlip;
  }

  function showChar(id, pos, instant) {
    var c = Story.chars[id];
    if (!c || !c.sprite) return;
    var e = charEls[id];
    if (!e) {
      e = el('<div class="char"><img alt=""></div>');
      e.firstChild.src = Story.img(c.sprite);
      ui.chars.appendChild(e); charEls[id] = e;
    }
    e.className = 'char pos-' + pos + (instant ? ' vis' : '');
    if (!instant) setTimeout(function () { e.classList.add('vis'); }, 30);
    st.chars[id] = pos;
  }

  function hideChar(id) {
    var e = charEls[id];
    if (!e) return;
    e.classList.remove('vis');
    setTimeout(function () { if (e.parentNode) e.parentNode.removeChild(e); }, 500);
    delete charEls[id]; delete st.chars[id];
  }

  function setSpeaker(id) {
    var any = id && charEls[id];
    for (var k in charEls) charEls[k].classList.toggle('shade', !!any && k !== id);
  }

  // ---------------------------------------------------------------- dialogue
  function hideDlg() { ui.dlg.className = 'dlg'; stopTyping(); advance = null; }

  function say(s) {
    curLine = s;
    ui.spots.style.display = 'none';   // hotspots are not clickable while someone is talking
    var c = s.say ? Story.chars[s.say] : null;
    ui.dlg.className = 'dlg on' + (s.narr ? ' narration' : '');
    var nm = c ? L(c.name) : '';
    ui.name.textContent = nm; ui.name.style.display = nm ? 'block' : 'none';
    if (c && c.head) { ui.head.src = Story.img(c.head); ui.head.style.display = 'block'; } else ui.head.style.display = 'none';
    setSpeaker(s.narr ? null : s.say);
    type(L(s));
    advance = function () { next(); };
  }

  function type(text) {
    stopTyping();
    var speed = { slow: 45, normal: 25, fast: 10, instant: 0 }[G.settings.speed];
    ui.more.style.visibility = 'hidden';
    if (!speed) { ui.txt.textContent = text; ui.more.style.visibility = 'visible'; return; }
    var n = 0;
    ui.txt.textContent = '';
    typing = { text: text, timer: setInterval(function () {
      if (UI.hasOverlay()) return;
      n++; ui.txt.textContent = text.slice(0, n);
      if (n >= text.length) finishTyping();
    }, speed) };
  }
  function finishTyping() {
    if (!typing) return;
    clearInterval(typing.timer); ui.txt.textContent = typing.text; typing = null; ui.more.style.visibility = 'visible';
  }
  function stopTyping() { if (typing) { clearInterval(typing.timer); typing = null; } }

  function refreshText() {   // language changed while playing
    if (!curLine || !ui.dlg || ui.dlg.className.indexOf('on') < 0) return;
    stopTyping();
    var c = curLine.say ? Story.chars[curLine.say] : null;
    ui.name.textContent = c ? L(c.name) : '';
    ui.txt.textContent = L(curLine); ui.more.style.visibility = 'visible';
  }

  function titleCard(s) {
    hideDlg();
    ui.title.innerHTML = '<div class="tt1"></div><div class="tt2"></div>';
    ui.title.firstChild.textContent = L(s.title);
    ui.title.lastChild.textContent = s.sub ? L(s.sub) : '';
    ui.title.className = 'titlecard on';
    var done = false;
    function go() { if (done) return; done = true; clearTimeout(titleTimer); ui.title.className = 'titlecard'; advance = null; next(); }
    clearTimeout(titleTimer);
    titleTimer = setTimeout(function () { if (UI.hasOverlay()) { titleTimer = setTimeout(go, 1500); } else go(); }, 3600);
    advance = go;
  }

  // ---------------------------------------------------------------- choices
  function choice(s) {
    hideDlg();
    ui.choices.innerHTML = '';
    s.choice.forEach(function (o) {
      var b = el('<button class="choice"></button>');
      b.textContent = L(o);
      b.onclick = function (e) {
        e.stopPropagation(); UI.click(); ui.choices.className = 'choices';
        if (o.set) for (var k in o.set) st.flags[k] = o.set[k];
        if (o.goto) jump(o.goto);
        next();
      };
      ui.choices.appendChild(b);
    });
    ui.choices.className = 'choices on';
  }

  // ---------------------------------------------------------------- notebook card + evidence
  function notebookCard(id) {
    var e = Story.notebook[id];
    var r = API.addNotebook(id, def.id);
    if (!e || !r.ok || !r.isNew) return false;
    nbList.push(id);
    API.sound('page');
    var box = el('<div class="paper nbpop"><div class="stamp small">NOTEBOOK</div><h3 data-i18n="game.nb_update"></h3><h4></h4><ul></ul><p class="small" data-i18n="game.cont"></p></div>');
    $('h4', box).textContent = L(e.title);
    var lines = e.lines ? (e.lines[I18N.get()] || e.lines.my || e.lines.en || []) : [];
    lines.forEach(function (ln) { var li = document.createElement('li'); li.textContent = ln; $('ul', box).appendChild(li); });
    var h = UI.overlay(box, { cls: 'dark', onClose: function () { if (running) next(); } });
    box.onclick = function () { h.close(); };
    return true;
  }

  /** Evidence popup. cb(collected) runs after it closes. */
  function evidencePopup(id, forced, cb) {
    var ev = Story.evidence[id];
    if (!ev) { if (cb) cb(false); return; }
    var has = evList.indexOf(id) >= 0, collected = false;
    var panel = el('<div class="panel evpop"><div class="evhead"></div><div class="evbody"></div><div class="row"></div></div>');
    $('.evhead', panel).textContent = has ? '' : t('game.found');
    $('.evbody', panel).appendChild(UI.evidenceCard(id));
    var row = $('.row', panel), h;
    if (!has) {
      var b = el('<button class="btn red"></button>'); b.textContent = t('game.collect');
      b.onclick = function () {
        var r = API.collectEvidence(id, def.id);
        if (!r.ok) { UI.toast(t(r.error)); return; }
        evList.push(id); collected = true; API.sound('evidence'); UI.toast(L(ev.name) + ' ✓'); h.close();
      };
      row.appendChild(b);
    }
    if (!forced || has) {
      var c = el('<button class="btn"></button>'); c.textContent = t('close'); c.onclick = function () { UI.click(); h.close(); }; row.appendChild(c);
    }
    h = UI.overlay(panel, { cls: 'dark', esc: !forced || has, onClose: function () { if (running && cb) cb(collected); } });
  }

  function afterCollect(id, collected, onEnd) {
    var ev = Story.evidence[id];
    if (collected && ev && ev.onCollect && ev.onCollect.length) { frames.push({ steps: ev.onCollect, i: 0, onEnd: onEnd }); next(); }
    else onEnd();
  }

  function gain(id) {
    if (evList.indexOf(id) >= 0) return false;
    hideDlg();
    evidencePopup(id, true, function (collected) { afterCollect(id, collected, next); });
    return true;
  }

  // ---------------------------------------------------------------- investigation (clickable hotspots)
  function investigate(cfg) {
    hideDlg();
    if (cfg.bg) setBg(cfg.bg);
    ui.spots.innerHTML = '';
    function has(id) { return evList.indexOf(id) >= 0; }
    function spotDone(sp) { return sp.container ? sp.items.every(has) : has(sp.ev); }
    cfg.spots.forEach(function (sp) {
      var d = el('<div class="spot"><i></i></div>');
      d.style.left = sp.x + '%'; d.style.top = sp.y + '%'; d.style.width = sp.w + '%'; d.style.height = sp.h + '%';
      d.onclick = function (e) { e.stopPropagation(); if (!UI.hasOverlay()) openSpot(sp); };
      sp._el = d; ui.spots.appendChild(d);
    });
    function refresh() {
      hideDlg();   // the dialogue box must not cover the hotspots
      ui.spots.style.display = 'block';
      var doneN = 0;
      cfg.spots.forEach(function (sp) {
        var done = spotDone(sp); if (done) doneN++;
        sp._el.style.display = (!done && (!sp.after || has(sp.after))) ? 'block' : 'none';
      });
      ui.banner.textContent = t('game.invest') + ' — ' + t('game.invest_n', { a: doneN, b: cfg.spots.length });
      ui.banner.className = 'banner on';
      if (doneN === cfg.spots.length) { ui.spots.innerHTML = ''; ui.banner.className = 'banner'; next(); }
    }
    function openSpot(sp) {
      UI.click('page');
      if (!sp.container) { evidencePopup(sp.ev, false, function (c) { afterCollect(sp.ev, c, refresh); }); return; }
      var box = el('<div class="panel contents"><h3></h3><div class="items"></div><div class="row"><button class="btn"></button></div></div>');
      $('h3', box).textContent = L(sp.title) + ' — ' + t('game.bag_title');
      var h = UI.overlay(box, { cls: 'dark' });
      sp.items.forEach(function (id) {
        if (has(id)) return;
        var ev = Story.evidence[id], b = el('<button class="itembtn"><img alt=""><span></span></button>');
        $('img', b).src = Story.img(ev.img); $('span', b).textContent = L(ev.name);
        b.onclick = function () { h.close(); evidencePopup(id, false, function (c) { afterCollect(id, c, refresh); }); };
        $('.items', box).appendChild(b);
      });
      var cl = $('.btn', box); cl.textContent = t('close'); cl.onclick = function () { UI.click(); h.close(); };
    }
    refresh();
  }

  // ---------------------------------------------------------------- interview: the player chooses the questions
  function showAsk(s, idx) {
    hideDlg();
    var cfg = s.ask, key = st.ch + ':' + idx;
    var done = st.asked[key] || (st.asked[key] = []);
    ui.ask.innerHTML = '<div class="asktitle"></div><div class="asklist"></div><div class="askend"></div>';
    $('.asktitle', ui.ask).textContent = cfg.title ? L(cfg.title) : '';
    var list = $('.asklist', ui.ask), required = 0, finished = 0;
    cfg.topics.forEach(function (tp) {
      var need = !tp.optional && (!tp.ev || tp.must);
      if (need) { required++; if (done.indexOf(tp.id) >= 0) finished++; }
      if (tp.after && !tp.after.every(function (a) { return done.indexOf(a) >= 0; })) return;
      if (tp.ev && evList.indexOf(tp.ev) < 0) return;
      var b = el('<button class="q"></button>');
      b.textContent = tp.ev ? t('game.show') + ': ' + L(Story.evidence[tp.ev].name) : L(tp.q);
      if (done.indexOf(tp.id) >= 0) b.className = 'q asked';
      b.onclick = function (e) {
        e.stopPropagation(); UI.click();
        var steps = tp.steps;
        if (!tp.ev && !tp.noq) {
          var q = JSON.parse(JSON.stringify(tp.q)); q.say = cfg.asker || 'detective';
          steps = [q].concat(tp.steps);
        }
        ui.ask.className = 'askbox';
        frames.push({ steps: steps, i: 0, onEnd: function () {
          if (done.indexOf(tp.id) < 0) done.push(tp.id);
          scheduleSave(); showAsk(s, idx);
        } });
        next();
      };
      list.appendChild(b);
    });
    var end = el('<button class="btn red"></button>');
    end.textContent = t('game.end_ask'); end.disabled = finished < required;
    end.onclick = function (e) { e.stopPropagation(); UI.click(); ui.ask.className = 'askbox'; next(); };
    $('.askend', ui.ask).appendChild(end);
    ui.ask.className = 'askbox on';
  }

  // ---------------------------------------------------------------- deduction: connect two clues
  function deduce(cfg, idx) {
    hideDlg();
    var key = 'dd' + st.ch + ':' + idx;
    var found = st.asked[key] || (st.asked[key] = []);
    var picked = [];
    function clueName(id) {
      if (Story.evidence[id]) return L(Story.evidence[id].name);
      return Story.notebook[id] ? L(Story.notebook[id].title) : id;
    }
    function owned(id) { return evList.indexOf(id) >= 0 || nbList.indexOf(id) >= 0; }

    var box = el('<div class="panel deduce"><h3 data-i18n="game.pick2"></h3><div class="clues"></div><div class="dstat"></div><div class="row"><button class="btn red conn"></button><button class="btn fin"></button></div></div>');
    var h = UI.overlay(box, { cls: 'dark', esc: false });
    function draw() {
      var wrap = $('.clues', box); wrap.innerHTML = '';
      cfg.clues.forEach(function (id) {
        if (!owned(id)) return;
        var c = el('<button class="clue' + (picked.indexOf(id) >= 0 ? ' on' : '') + '"></button>');
        c.textContent = clueName(id);
        c.onclick = function () {
          UI.click('page');
          var p = picked.indexOf(id);
          if (p >= 0) picked.splice(p, 1); else { if (picked.length >= 2) picked.shift(); picked.push(id); }
          draw();
        };
        wrap.appendChild(c);
      });
      $('.dstat', box).textContent = t('game.found_n', { a: found.length, b: cfg.need });
      $('.conn', box).textContent = t('game.connect'); $('.conn', box).disabled = picked.length !== 2;
      $('.fin', box).textContent = t('game.think_done'); $('.fin', box).disabled = found.length < cfg.need;
    }
    $('.conn', box).onclick = function () {
      var a = picked[0], b = picked[1], hit = -1;
      cfg.pairs.forEach(function (p, i) { if ((p.a === a && p.b === b) || (p.a === b && p.b === a)) hit = i; });
      if (hit >= 0 && found.indexOf(hit) >= 0) { UI.toast(t('game.same')); return; }
      var steps;
      if (hit >= 0) { found.push(hit); steps = cfg.pairs[hit].lines; API.sound('evidence'); }
      else { var x = t('game.no_link'); steps = cfg.fail || [{ narr: 1, my: x, en: x, ja: x }]; API.sound('error'); }
      h.close();
      picked = [];
      frames.push({ steps: steps, i: 0, onEnd: function () { scheduleSave(); deduce(cfg, idx); } });
      next();
    };
    $('.fin', box).onclick = function () { UI.click(); h.close(); next(); };
    draw();
  }

  // ---------------------------------------------------------------- final accusation
  function accuse(cfg) {
    hideDlg();
    var box = el('<div class="accuse"><h2 data-i18n="game.who"></h2><div class="suspects"></div></div>');
    var h = UI.overlay(box, { cls: 'dark', esc: false });
    cfg.suspects.forEach(function (sp) {
      var c = Story.chars[sp.id];
      var card = el('<div class="suspect"><img alt=""><h4></h4><ul></ul><button class="btn red"></button></div>');
      $('img', card).src = Story.img(c.head); $('h4', card).textContent = L(c.name);
      var qs = sp.qs ? (sp.qs[I18N.get()] || sp.qs.my || sp.qs.en || []) : [];
      qs.forEach(function (q) { var li = document.createElement('li'); li.textContent = q; $('ul', card).appendChild(li); });
      var b = $('button', card); b.textContent = t('game.accuse');
      b.onclick = function () {
        UI.click();
        UI.modal({ title: t('game.accuse'), text: t('game.accuse_q', { name: L(c.name) }), onOk: function () {
          h.close(); jump(sp.goto); next(); return null;
        } });
      };
      $('.suspects', box).appendChild(card);
    });
    I18N.apply(box);
  }

  // ---------------------------------------------------------------- endings
  function endScreen(s) {
    hideDlg();
    var kind = s.end;
    if (kind === 'win') { API.completeCase(def.id); G.progress[def.id] = { completed: true, hasSave: false }; ended = true; }
    if (kind === 'closed') { API.startCase(def.id); ended = true; }
    var follow = null;
    for (var i = 0; i < Story.cases.length; i++) if (Story.cases[i].unlockedBy === def.id) follow = Story.cases[i];

    var box = el('<div class="endscr"><h1 class="' + kind + '"></h1><div class="bio"></div><p class="unlock"></p><div class="row"></div></div>');
    $('h1', box).textContent = t(kind === 'win' ? 'game.win' : kind === 'lose' ? 'game.lose' : 'game.closed');
    if (s.bio && Story.chars[s.bio]) {
      var c = Story.chars[s.bio], bio = $('.bio', box);
      bio.innerHTML = '<img alt=""><div><small></small><h3></h3><ul></ul></div>';
      $('img', bio).src = Story.img(c.head); $('small', bio).textContent = t('game.bio'); $('h3', bio).textContent = L(c.name);
      var lines = c.bio ? (c.bio[I18N.get()] || c.bio.my || c.bio.en || []) : [];
      lines.forEach(function (ln) { var li = document.createElement('li'); li.textContent = ln; $('ul', bio).appendChild(li); });
    }
    if (kind === 'win' && follow) $('.unlock', box).textContent = t('cases.unlocked');
    var row = $('.row', box), h;
    if (kind === 'lose' && s.retry) {
      var r = el('<button class="btn red"></button>'); r.textContent = t('game.retry');
      r.onclick = function () { UI.click(); h.close(); jump(s.retry); next(); };
      row.appendChild(r);
    }
    var b = el('<button class="btn' + (kind === 'lose' && s.retry ? '' : ' red') + '"></button>'); b.textContent = t('game.to_cases');
    b.onclick = function () {
      UI.click(); h.close(); stop(); UI.cases();
      if (kind === 'win' && follow) UI.toast(t('cases.unlocked'));
    };
    row.appendChild(b);
    h = UI.overlay(box, { cls: 'black', esc: false });
  }

  return {
    start: start, stop: stop, key: key, saveNow: saveNow, refreshText: refreshText,
    caseDef: function () { return def; },
    evidenceIds: function () { return evList.slice(); },
    notebookIds: function () { return nbList.slice(); }
  };
})();

/* Entry point. Java calls BJ.start() when the page is ready (window.jb exists). */
var BJ = (function () {
  var started = false;

  function start() {
    if (started) return;
    started = true;
    window.onerror = function (msg, src, line) { API.log('JS error: ' + msg + ' (' + line + ')'); };
    UI.init();
    Story.init();
    Settings.loadDefaults();
    API.music('ambient');
    document.addEventListener('keydown', function (e) {
      if (UI.key(e)) { e.preventDefault(); return; }
      if (Engine.key(e)) { e.preventDefault(); return; }
      if (e.key === 'F11') { G.settings.full = !G.settings.full; Settings.save(); e.preventDefault(); }
    });
    document.addEventListener('contextmenu', function (e) { e.preventDefault(); });
    UI.login();
  }

  return { start: start, saveNow: function () { Engine.saveNow(); } };
})();

G.afterLogin = function (name) {
  G.me = name;
  Settings.load();
  UI.menu();
};

/* Browser testing (no Java window): start by hand. Inside the game window Java starts it. */
if (navigator.userAgent.indexOf('BJFX') < 0) {
  window.addEventListener('load', function () { BJ.start(); });
}

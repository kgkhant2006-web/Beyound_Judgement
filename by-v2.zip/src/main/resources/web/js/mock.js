/* Browser-only fake of the Java bridge so the HTML can be tested in Chrome/VS Code without Java or MySQL.
   It is used ONLY when the page is not running inside the game window. */
(function () {
  if (navigator.userAgent.indexOf('BJFX') >= 0) return;
  var KEY = 'bj-mock-db';
  function load() { try { return JSON.parse(localStorage.getItem(KEY)) || { next: 1, players: [], notes: 1 }; } catch (e) { return { next: 1, players: [], notes: 1 }; } }
  function save(d) { localStorage.setItem(KEY, JSON.stringify(d)); }
  var me = null;
  function P(d) { for (var i = 0; i < d.players.length; i++) if (d.players[i].id === me) return d.players[i]; return null; }
  function ok(o) { o = o || {}; o.ok = true; return JSON.stringify(o); }
  function err(k) { return JSON.stringify({ ok: false, error: k }); }
  function find(d, n) { for (var i = 0; i < d.players.length; i++) if (d.players[i].name.toLowerCase() === String(n).toLowerCase()) return d.players[i]; return null; }
  function prog(p, c) { return p.progress[c] || (p.progress[c] = { completed: false, state: null }); }
  window.jb = {
    status: function () { return ok({ db: true, error: '' }); },
    retryDb: function () { return this.status(); },
    readResource: function (path) {
      var x = new XMLHttpRequest(); x.open('GET', '../' + path, false);
      try { x.send(); return x.status === 200 || x.status === 0 ? x.responseText : ''; } catch (e) { return ''; }
    },
    log: function (m) { console.log('[JS]', m); },
    exitGame: function () { console.log('exit'); }, setFullscreen: function () {},
    getLang: function () { return localStorage.getItem('bj-lang') || 'en'; },
    setLang: function (l) { localStorage.setItem('bj-lang', l); },
    listAccounts: function () {
      var d = load();
      return ok({ max: 3, accounts: d.players.map(function (p) { return { name: p.name, last: p.last || '', case1Done: !!(p.progress.case1 && p.progress.case1.completed) }; }) });
    },
    register: function (n, pw, pw2) {
      var d = load(); n = String(n).trim();
      if (!/^[\w\u1000-\u109F -]{3,20}$/.test(n)) return err('err.name_invalid');
      if (pw.length < 4) return err('err.pw_short'); if (pw !== pw2) return err('err.pw_mismatch');
      if (d.players.length >= 3) return err('err.limit'); if (find(d, n)) return err('err.name_taken');
      var p = { id: d.next++, name: n, pw: pw, last: '', progress: {}, evidence: [], notebook: [], notes: [], settings: null };
      d.players.push(p); save(d); me = p.id; return ok({ name: n });
    },
    login: function (n, pw) {
      var d = load(), p = find(d, n); if (!p || p.pw !== pw) return err('err.bad_login');
      p.last = new Date().toISOString().replace('T', ' ').slice(0, 16); save(d); me = p.id; return ok({ name: p.name });
    },
    logout: function () { me = null; return ok(); },
    deleteAccount: function (n, pw) {
      var d = load(), p = find(d, n); if (!p || p.pw !== pw) return err('err.bad_login');
      d.players = d.players.filter(function (x) { return x !== p && x.id !== p.id; }); save(d); if (me === p.id) me = null; return ok();
    },
    me: function () { var p = P(load()); return p ? ok({ name: p.name }) : err('err.no_session'); },
    getProgress: function () {
      var d = load(), p = P(d), cs = {}; for (var k in p.progress) cs[k] = { completed: p.progress[k].completed, hasSave: !!p.progress[k].state };
      return ok({ cases: cs });
    },
    startCase: function (c) {
      var d = load(), p = P(d), cur = prog(p, c); cur.state = null;
      p.evidence = p.evidence.filter(function (e) { return e.c !== c; }); p.notebook = p.notebook.filter(function (e) { return e.c !== c; }); save(d); return ok();
    },
    saveState: function (c, st) { var d = load(), p = P(d); prog(p, c).state = st; save(d); return ok(); },
    loadState: function (c) { var p = P(load()); return ok({ state: prog(p, c).state }); },
    completeCase: function (c) { var d = load(), p = P(d), cur = prog(p, c); cur.completed = true; cur.state = null; save(d); return ok(); },
    collectEvidence: function (id, c) { var d = load(), p = P(d); var has = p.evidence.some(function (e) { return e.id === id; }); if (!has) p.evidence.push({ id: id, c: c }); save(d); return ok({ isNew: !has }); },
    listEvidence: function () { return ok({ ids: P(load()).evidence.map(function (e) { return e.id; }) }); },
    addNotebook: function (id, c) { var d = load(), p = P(d); var has = p.notebook.some(function (e) { return e.id === id; }); if (!has) p.notebook.push({ id: id, c: c }); save(d); return ok({ isNew: !has }); },
    listNotebook: function () { return ok({ ids: P(load()).notebook.map(function (e) { return e.id; }) }); },
    listNotes: function () { return ok({ notes: P(load()).notes.slice().reverse() }); },
    saveNote: function (id, t, c) {
      var d = load(), p = P(d), now = new Date().toISOString().replace('T', ' ').slice(0, 16); id = parseInt(id, 10) || 0;
      if (!id) { id = d.notes++; p.notes.push({ id: id, title: t, content: c, updated: now }); }
      else p.notes.forEach(function (n) { if (n.id === id) { n.title = t; n.content = c; n.updated = now; } });
      save(d); return ok({ id: id });
    },
    deleteNote: function (id) { var d = load(), p = P(d); id = parseInt(id, 10); p.notes = p.notes.filter(function (n) { return n.id !== id; }); save(d); return ok(); },
    getSettings: function () { return ok({ settings: P(load()).settings }); },
    saveSettings: function (s) { var d = load(), p = P(d); p.settings = s; save(d); return ok(); },
    playSound: function () {}, playMusic: function () {}, stopMusic: function () {}, setVolumes: function () {}
  };
})();

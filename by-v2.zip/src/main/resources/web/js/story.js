/* Loads the story data through the Java bridge (everything is plain JSON in resources/story-line). */
var Story = {
  cases: [], chars: {}, evidence: {}, notebook: {}, chapters: {},
  json: function (path) {
    var s = API.readResource(path);
    if (!s) { API.log('Missing story file: ' + path); return null; }
    try { return JSON.parse(s); } catch (e) { API.log('Bad JSON in ' + path + ': ' + e.message); return null; }
  },
  init: function () {
    this.cases = this.json('story-line/cases.json') || [];
    this.chars = this.json('story-line/characters.json') || {};
    this.evidence = this.json('story-line/evidence.json') || {};
    this.notebook = this.json('story-line/notebook.json') || {};
  },
  /** Returns the chapter objects of a case, in order. */
  loadCase: function (def) {
    var list = [];
    for (var i = 0; i < def.chapters.length; i++) {
      var id = def.chapters[i];
      if (!this.chapters[id]) this.chapters[id] = this.json('story-line/' + id + '.json') || { id: id, steps: [] };
      list.push(this.chapters[id]);
    }
    return list;
  },
  caseById: function (id) {
    for (var i = 0; i < this.cases.length; i++) if (this.cases[i].id === id) return this.cases[i];
    return null;
  },
  img: function (name) { return '../img/' + name; }
};

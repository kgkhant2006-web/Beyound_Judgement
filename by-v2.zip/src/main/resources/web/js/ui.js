/* Screens + overlays. Markup is built here; styling is in css/main.css. */
var G = {   // global state
  me: '', progress: {}, settings: null,
  defaults: { lang: 'en', master: 80, music: 50, sfx: 70, speed: 'normal', size: 'medium', full: false, hints: true }
};

var UI = (function () {
  var t = I18N.t, L = I18N.L;
  var stage, screen, ovLayer, toastEl, overlays = [], current = null;

  function el(html) {
    var d = document.createElement('div');
    d.innerHTML = html;
    return d.firstElementChild;
  }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function $(sel, root) { return (root || document).querySelector(sel); }
  function $$(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function click(sound) { API.sound(sound || 'click'); }

  // ------------------------------------------------------------------ layout
  function init() {
    stage = $('#stage');
    stage.innerHTML = '<div id="screen" class="layer"></div><div id="fx" class="layer"><div class="fog f1"></div><div class="fog f2"></div><div class="vig"></div><div class="flick"></div></div><div id="ov" class="layer"></div><div id="toast"></div>';
    screen = $('#screen'); ovLayer = $('#ov'); toastEl = $('#toast');
    function fit() {
      var s = Math.min(window.innerWidth / 1280, window.innerHeight / 720);
      stage.style.transform = 'scale(' + s + ')';
      stage.style.left = ((window.innerWidth - 1280 * s) / 2) + 'px';
      stage.style.top = ((window.innerHeight - 720 * s) / 2) + 'px';
    }
    window.addEventListener('resize', fit); fit();
  }

  function show(name, build, keepOverlays) {
    if (!keepOverlays) closeAllOverlays();
    current = { name: name, build: build };
    screen.innerHTML = '';
    screen.className = 'layer scr-' + name;
    build(screen);
    I18N.apply(screen);
  }
  function rerender() {
    if (!current) return;
    if (current.name !== 'game') show(current.name, current.build, true);
    else { I18N.apply(screen); if (window.Engine) Engine.refreshText(); }
    I18N.apply(ovLayer);
  }
  function screenName() { return current ? current.name : ''; }

  function toast(msg) {
    toastEl.textContent = msg; toastEl.className = 'on';
    clearTimeout(toast._t);
    toast._t = setTimeout(function () { toastEl.className = ''; }, 2400);
  }

  // ------------------------------------------------------------------ overlays (stack, ESC closes the top one)
  function overlay(node, opts) {
    opts = opts || {};
    var wrap = el('<div class="ov-wrap' + (opts.cls ? ' ' + opts.cls : '') + '"></div>');
    wrap.appendChild(node);
    ovLayer.appendChild(wrap);
    var h = { node: wrap, opts: opts, close: function () { closeOverlay(h); } };
    overlays.push(h);
    I18N.apply(wrap);
    return h;
  }
  function closeOverlay(h) {
    var i = overlays.indexOf(h);
    if (i < 0) return;
    overlays.splice(i, 1);
    if (h.node.parentNode) h.node.parentNode.removeChild(h.node);
    if (h.opts.onClose) h.opts.onClose();
  }
  function closeAllOverlays() { while (overlays.length) closeOverlay(overlays[overlays.length - 1]); }
  function hasOverlay() { return overlays.length > 0; }
  /** Returns true when the key was used. */
  function key(e) {
    if (!overlays.length) return false;
    var top = overlays[overlays.length - 1];
    if (top.opts.keys && top.opts.keys(e)) return true;
    if (e.key === 'Escape' && top.opts.esc !== false) { click(); closeOverlay(top); return true; }
    return top.opts.block !== false;
  }

  function modal(o) {
    var box = el('<div class="panel modal"><h3></h3><p></p>' + (o.input ? '<input class="in" type="password" maxlength="50">' : '') + '<div class="err"></div><div class="row"><button class="btn cancel"></button><button class="btn red ok"></button></div></div>');
    $('h3', box).textContent = o.title; $('p', box).textContent = o.text;
    $('.cancel', box).textContent = o.cancelText || t('cancel'); $('.ok', box).textContent = o.okText || t('confirm');
    var h = overlay(box, { cls: 'dark' });
    var inp = $('input', box); if (inp) setTimeout(function () { inp.focus(); }, 50);
    function go() {
      var v = inp ? inp.value : '';
      var r = o.onOk ? o.onOk(v) : null;     // return an error text to keep the modal open
      if (r) { $('.err', box).textContent = r; return; }
      h.close();
    }
    $('.ok', box).onclick = function () { click(); go(); };
    $('.cancel', box).onclick = function () { click(); h.close(); };
    if (inp) inp.onkeydown = function (e) { if (e.key === 'Enter') go(); };
    return h;
  }

  // ------------------------------------------------------------------ LOGIN
  function langBar() {
    var bar = el('<div class="langbar"><button data-l="en">EN</button><button data-l="my">မြန်မာ</button><button data-l="ja">日本語</button></div>');
    $$('button', bar).forEach(function (b) {
      if (b.getAttribute('data-l') === I18N.get()) b.className = 'on';
      b.onclick = function () { click(); Settings.setLang(b.getAttribute('data-l')); };
    });
    return bar;
  }

  function login() {
    show('login', function (root) {
      root.appendChild(el('<div class="bgimg" style="background-image:url(../img/corkboard.jpg)"></div>'));
      root.appendChild(el('<div class="dim"></div>'));
      root.appendChild(langBar());
      var card = el(
        '<div class="paper login">' +
        '<div class="stamp">CONFIDENTIAL</div>' +
        '<div class="brand">BEYOND JUDGEMENT</div><div class="brand2" data-i18n="subtitle"></div>' +
        '<h2 data-i18n="login.card"></h2><p class="hint" data-i18n="login.hint"></p>' +
        '<div class="cols"><div class="box saved"><h3><span data-i18n="login.saved"></span> <b id="cnt"></b></h3><div id="slots"></div></div>' +
        '<div class="box form" id="formbox"></div></div></div>');
      root.appendChild(card);
      renderLoginForm(card);
    });
  }

  function renderLoginForm(card) {
    var st = API.status();
    var formbox = $('#formbox', card);
    if (!st.db) {
      $('#slots', card).innerHTML = '';
      formbox.innerHTML = '<div class="dberr"><b data-i18n="db.offline"></b><p data-i18n="db.help"></p><code></code><button class="btn red" id="retry" data-i18n="db.retry"></button></div>';
      $('code', formbox).textContent = st.error || '';
      $('#retry', formbox).onclick = function () { click(); API.retryDb(); renderLoginForm(card); };
      I18N.apply(card);
      return;
    }
    var acc = API.listAccounts();
    var list = acc.ok ? acc.accounts : [], max = acc.max || 3, tab = 'in';
    $('#cnt', card).textContent = list.length + '/' + max;
    var slots = $('#slots', card); slots.innerHTML = '';
    for (var i = 0; i < max; i++) {
      var a = list[i];
      if (!a) { slots.appendChild(el('<div class="slot empty"><span data-i18n="login.empty"></span></div>')); continue; }
      var row = el('<div class="slot"><img src="../img/detetive-h.png" alt=""><div class="who"><b></b><small></small><small class="ok"></small></div><button class="mini pick" data-i18n="login.pick"></button><button class="mini del" title="Delete">✕</button></div>');
      $('b', row).textContent = a.name;
      $('small', row).textContent = a.last ? t('login.last') + ': ' + a.last : '';
      $('.ok', row).textContent = a.case1Done ? t('login.solved') : '';
      (function (acct, rowEl) {
        $('.pick', rowEl).onclick = function () { click(); setTab('in'); $('#u', formbox).value = acct.name; $('#p', formbox).focus(); };
        $('.del', rowEl).onclick = function () {
          click();
          modal({ title: t('del.title'), text: t('del.text', { name: acct.name }), input: true, onOk: function (pw) {
            var r = API.deleteAccount(acct.name, pw);
            if (!r.ok) return t(r.error);
            toast(t('del.title') + ': ' + acct.name); renderLoginForm(card); return null;
          } });
        };
      })(a, row);
      slots.appendChild(row);
    }
    formbox.innerHTML =
      '<div class="tabs"><button id="t-in" data-i18n="login.tab_in"></button><button id="t-new" data-i18n="login.tab_new"></button></div>' +
      '<label data-i18n="login.name"></label><input class="in" id="u" maxlength="20" autocomplete="off">' +
      '<label data-i18n="login.pw"></label><input class="in" id="p" type="password" maxlength="50">' +
      '<div id="f2"><label data-i18n="login.pw2"></label><input class="in" id="p2" type="password" maxlength="50"></div>' +
      '<div class="err" id="err"></div><button class="btn red wide" id="go"></button><p class="small" id="lim"></p>';
    function setTab(x) {
      tab = x;
      $('#t-in', formbox).className = x === 'in' ? 'on' : '';
      $('#t-new', formbox).className = x === 'new' ? 'on' : '';
      $('#f2', formbox).style.display = x === 'new' ? 'block' : 'none';
      $('#go', formbox).setAttribute('data-i18n', x === 'in' ? 'login.open' : 'login.create');
      $('#lim', formbox).textContent = (x === 'new' && list.length >= max) ? t('login.limit') : '';
      $('#err', formbox).textContent = '';
      I18N.apply(formbox);
    }
    function submit() {
      var u = $('#u', formbox).value, p = $('#p', formbox).value, p2 = $('#p2', formbox).value;
      if (!u.trim() || !p || (tab === 'new' && !p2)) { $('#err', formbox).textContent = t('err.empty'); return; }
      var r = tab === 'in' ? API.login(u, p) : API.register(u, p, p2);
      if (!r.ok) { API.sound('error'); $('#err', formbox).textContent = t(r.error); return; }
      click(); G.afterLogin(r.name);
    }
    $('#t-in', formbox).onclick = function () { click(); setTab('in'); };
    $('#t-new', formbox).onclick = function () { click(); setTab('new'); };
    $('#go', formbox).onclick = submit;
    $$('input', formbox).forEach(function (i) { i.onkeydown = function (e) { if (e.key === 'Enter') submit(); }; });
    setTab('in');
    I18N.apply(card);
  }

  // ------------------------------------------------------------------ MAIN MENU (office)
  function menu() {
    API.music('ambient');
    show('menu', function (root) {
      root.appendChild(el('<div class="bgimg office" style="background-image:url(../img/office.jpg)"></div>'));
      root.appendChild(el('<div class="dim left"></div>'));
      root.appendChild(el('<div class="lamp"></div>'));
      var who = el('<div class="whoami"></div>'); who.textContent = t('menu.welcome', { name: G.me }); root.appendChild(who);
      var box = el('<div class="titleblock"><h1>BEYOND<br>JUDGEMENT</h1><h2 data-i18n="subtitle"></h2>' +
        '<ul class="menulist"><li data-a="start" data-i18n="menu.start"></li><li data-a="settings" data-i18n="menu.settings"></li><li data-a="switch" data-i18n="menu.switch"></li><li data-a="exit" data-i18n="menu.exit"></li></ul></div>');
      root.appendChild(box);
      $$('li', box).forEach(function (li) {
        li.onclick = function () {
          click(); var a = li.getAttribute('data-a');
          if (a === 'start') cases();
          else if (a === 'settings') settingsPanel();
          else if (a === 'switch') { API.logout(); G.me = ''; login(); }
          else API.exitGame();
        };
      });
    });
  }

  // ------------------------------------------------------------------ CASE FILES
  function isUnlocked(def) {
    if (!def.unlockedBy) return true;
    var p = G.progress[def.unlockedBy];
    return !!(p && p.completed);
  }

  function cases(selectedId) {
    var pr = API.getProgress(); G.progress = pr.ok ? pr.cases : {};
    var sel = selectedId || Story.cases[0].id;
    show('cases', function (root) {
      root.appendChild(el('<div class="bgimg desk" style="background-image:url(../img/office.jpg)"></div>'));
      root.appendChild(el('<div class="dim"></div>'));
      var h = el('<h2 class="cases-title" data-i18n="cases.title"></h2>'); root.appendChild(h);
      var back = el('<button class="btn back" data-i18n="back"></button>'); back.onclick = function () { click(); menu(); }; root.appendChild(back);
      var shelf = el('<div class="shelf"></div>'); root.appendChild(shelf);
      var detail = el('<div class="panel detail"></div>'); root.appendChild(detail);

      Story.cases.forEach(function (def) {
        var unlocked = isUnlocked(def), done = !!(G.progress[def.id] && G.progress[def.id].completed);
        var f = el('<div class="folder' + (unlocked ? '' : ' locked') + (def.id === sel ? ' sel' : '') + '"><div class="tab"></div><div class="body"><div class="code"></div><div class="ttl"></div><div class="state"></div></div></div>');
        $('.tab', f).textContent = t('cases.code', { n: def.code });
        $('.code', f).textContent = t('cases.code', { n: def.code });
        $('.ttl', f).textContent = unlocked ? L(def.title) : '???';
        $('.state', f).textContent = !unlocked ? t('cases.locked') : (done ? t('cases.solved') : '');
        if (!unlocked) f.appendChild(el('<div class="padlock"><i></i></div>'));
        f.onclick = function () { click('page'); cases(def.id); };
        shelf.appendChild(f);
      });

      var def = Story.caseById(sel), unlocked = isUnlocked(def), prog = G.progress[def.id] || {};
      var d = '<h3></h3><p class="desc"></p><div class="row"></div>';
      detail.innerHTML = d;
      $('h3', detail).textContent = unlocked ? t('cases.code', { n: def.code }) + ' — ' + L(def.title) : t('cases.locked');
      $('.desc', detail).textContent = unlocked ? L(def.desc) : t('cases.locked_hint');
      var row = $('.row', detail);
      function btn(label, cls, fn) { var b = el('<button class="btn ' + cls + '"></button>'); b.textContent = label; b.onclick = function () { click(); fn(); }; row.appendChild(b); }
      if (unlocked && def.chapters.length === 0) {
        row.appendChild(el('<p class="small">' + esc(t('cases.soon')) + '</p>'));
      } else if (unlocked) {
        if (prog.hasSave) {
          btn(t('cases.continue'), 'red', function () { Engine.start(def, true); });
          btn(t('cases.over'), '', function () {
            modal({ title: t('cases.over'), text: t('cases.over_q'), onOk: function () { Engine.start(def, false); return null; } });
          });
        } else {
          btn(prog.completed ? t('cases.again') : t('cases.start'), 'red', function () { Engine.start(def, false); });
        }
      }
    });
  }

  // ------------------------------------------------------------------ PAUSE
  function pause() {
    if (hasOverlay()) return;
    API.sound('page'); Engine.saveNow();
    var box = el('<div class="pause"><div class="orn"></div><h2 data-i18n="pause.title"></h2><ul class="menulist center">' +
      '<li data-a="resume" data-i18n="pause.resume"></li><li data-a="restart" data-i18n="pause.restart"></li><li data-a="settings" data-i18n="pause.settings"></li><li data-a="menu" data-i18n="pause.menu"></li><li data-a="quit" data-i18n="pause.quit"></li></ul><div class="orn bot"></div></div>');
    var keys = el('<div class="keyhint" data-i18n="pause.keys"></div>');
    var wrap = el('<div></div>'); wrap.appendChild(box); wrap.appendChild(keys);
    var items = $$('li', box), idx = 0;
    function mark() { items.forEach(function (li, i) { li.className = i === idx ? 'sel' : ''; }); }
    mark();
    var h = overlay(wrap, { cls: 'pausebg', keys: function (e) {
      if (e.key === 'ArrowDown') { idx = (idx + 1) % items.length; mark(); return true; }
      if (e.key === 'ArrowUp') { idx = (idx + items.length - 1) % items.length; mark(); return true; }
      if (e.key === 'Enter') { act(items[idx].getAttribute('data-a')); return true; }
      return false;
    } });
    function act(a) {
      click();
      if (a === 'resume') h.close();
      else if (a === 'settings') settingsPanel();
      else if (a === 'restart') modal({ title: t('pause.restart'), text: t('cases.over_q'), onOk: function () { var def = Engine.caseDef(); h.close(); Engine.start(def, false); return null; } });
      else if (a === 'menu') { h.close(); Engine.stop(); cases(); }
      else API.exitGame();
    }
    items.forEach(function (li, i) { li.onmouseover = function () { idx = i; mark(); }; li.onclick = function () { act(li.getAttribute('data-a')); }; });
  }

  // ------------------------------------------------------------------ SETTINGS
  function settingsPanel() {
    var tabs = ['gameplay', 'audio', 'display', 'language'], cur = 0, S = G.settings;
    var box = el('<div class="settings"><button class="x">✕</button><h2 data-i18n="set.title"></h2><div class="stabs"></div><div class="sbody"></div><div class="keyhint" data-i18n="set.keys"></div></div>');
    var tabsEl = $('.stabs', box), body = $('.sbody', box);
    function seg(label, field, opts) {
      var row = el('<div class="srow"><span></span><div class="seg"></div></div>');
      $('span', row).textContent = t(label);
      opts.forEach(function (o) {
        var b = el('<button></button>'); b.textContent = t(o[1]); if (S[field] === o[0]) b.className = 'on';
        b.onclick = function () { click(); S[field] = o[0]; Settings.save(); draw(); };
        $('.seg', row).appendChild(b);
      });
      return row;
    }
    function slider(label, field) {
      var row = el('<div class="srow"><span></span><input type="range" min="0" max="100"><b></b></div>');
      var inp = $('input', row); $('span', row).textContent = t(label); inp.value = S[field]; $('b', row).textContent = S[field];
      inp.oninput = function () { S[field] = parseInt(inp.value, 10); $('b', row).textContent = S[field]; Settings.apply(false); };
      inp.onchange = function () { click(); Settings.save(); };
      return row;
    }
    function toggle(label, field) {
      var row = el('<div class="srow"><span></span><button class="sw"><i></i></button></div>');
      $('span', row).textContent = t(label);
      var b = $('.sw', row); b.className = 'sw' + (S[field] ? ' on' : '');
      b.onclick = function () { click(); S[field] = !S[field]; Settings.save(); draw(); };
      return row;
    }
    function draw() {
      tabsEl.innerHTML = '';
      tabs.forEach(function (n, i) {
        var b = el('<button></button>'); b.textContent = t('set.' + n); if (i === cur) b.className = 'on';
        b.onclick = function () { click(); cur = i; draw(); }; tabsEl.appendChild(b);
      });
      body.innerHTML = '';
      var n = tabs[cur];
      if (n === 'gameplay') {
        body.appendChild(seg('set.speed', 'speed', [['slow', 'set.slow'], ['normal', 'set.normal'], ['fast', 'set.fast'], ['instant', 'set.instant']]));
        body.appendChild(toggle('set.hints', 'hints'));
      } else if (n === 'audio') {
        body.appendChild(slider('set.master', 'master')); body.appendChild(slider('set.music', 'music')); body.appendChild(slider('set.sfx', 'sfx'));
      } else if (n === 'display') {
        body.appendChild(toggle('set.full', 'full'));
        body.appendChild(seg('set.size', 'size', [['small', 'set.small'], ['medium', 'set.medium'], ['large', 'set.large']]));
      } else {
        var row = el('<div class="srow langs"></div>');
        [['en', 'English'], ['my', 'မြန်မာ'], ['ja', '日本語']].forEach(function (l) {
          var b = el('<button></button>'); b.textContent = l[1]; if (I18N.get() === l[0]) b.className = 'on';
          b.onclick = function () { click(); Settings.setLang(l[0]); };
          row.appendChild(b);
        });
        body.appendChild(row);
      }
      I18N.apply(box);
    }
    var h = overlay(box, { cls: 'dark', keys: function (e) {
      if (e.key === 'q' || e.key === 'Q') { cur = (cur + tabs.length - 1) % tabs.length; draw(); return true; }
      if (e.key === 'e' || e.key === 'E') { cur = (cur + 1) % tabs.length; draw(); return true; }
      return false;
    }, onClose: function () { Settings.save(); } });
    $('.x', box).onclick = function () { click(); h.close(); };
    box._redraw = draw;
    h.redraw = draw;
    draw();
    settingsPanel.current = h;
    return h;
  }

  // ------------------------------------------------------------------ EVIDENCE CARD (shared by popup + inventory)
  function evidenceCard(id, extra) {
    var ev = Story.evidence[id];
    var card = el('<div class="evcard"><div class="evimg"><img alt=""></div><div class="evtxt"><h3></h3><p class="evdesc"></p><ul class="evinfo"></ul><div class="evpages"></div></div></div>');
    if (!ev) return card;
    $('img', card).src = Story.img(ev.img);
    $('h3', card).textContent = L(ev.name);
    $('.evdesc', card).textContent = L(ev.desc);
    var info = ev.info ? (ev.info[I18N.get()] || ev.info.my || ev.info.en || []) : [];
    info.forEach(function (line) { var li = document.createElement('li'); li.textContent = line; $('.evinfo', card).appendChild(li); });
    if (ev.pages && ev.pages.length) {
      var p = 0, pg = $('.evpages', card);
      pg.innerHTML = '<div class="page"></div><div class="pnav"><button class="mini pv">◀</button><span></span><button class="mini nx">▶</button></div>';
      var draw = function () {
        $('.page', pg).textContent = L(ev.pages[p]);
        $('span', pg).textContent = t('inv.page', { n: p + 1, m: ev.pages.length });
      };
      $('.pv', pg).onclick = function () { if (p > 0) { p--; API.sound('page'); draw(); } };
      $('.nx', pg).onclick = function () { if (p < ev.pages.length - 1) { p++; API.sound('page'); draw(); } };
      draw();
    }
    if (extra) card.appendChild(extra);
    return card;
  }

  // ------------------------------------------------------------------ INVENTORY
  function inventory(tab) {
    var cur = tab || 'ev';
    var box = el('<div class="inv"><button class="x">✕</button><h2 data-i18n="inv.title"></h2><div class="itabs"></div><div class="ibody"></div></div>');
    var tabsEl = $('.itabs', box), body = $('.ibody', box);
    var h = overlay(box, { cls: 'dark' });
    $('.x', box).onclick = function () { click(); h.close(); };

    function draw() {
      tabsEl.innerHTML = '';
      [['ev', 'inv.ev'], ['nb', 'inv.nb'], ['notes', 'inv.notes']].forEach(function (x) {
        var b = el('<button></button>'); b.textContent = t(x[1]); if (cur === x[0]) b.className = 'on';
        b.onclick = function () { click('page'); cur = x[0]; draw(); }; tabsEl.appendChild(b);
      });
      body.innerHTML = '';
      if (cur === 'ev') drawEvidence(); else if (cur === 'nb') drawNotebook(); else drawNotes();
    }
    function drawEvidence() {
      var ids = Engine.evidenceIds();
      if (!ids.length) { body.appendChild(el('<p class="empty">' + esc(t('inv.empty_ev')) + '</p>')); return; }
      var grid = el('<div class="evgrid"></div>'), view = el('<div class="evview"><p class="empty">' + esc(t('inv.select')) + '</p></div>');
      ids.forEach(function (id) {
        var ev = Story.evidence[id]; if (!ev) return;
        var c = el('<div class="evtile"><img alt=""><span></span></div>');
        $('img', c).src = Story.img(ev.img); $('span', c).textContent = L(ev.name);
        c.onclick = function () {
          click('page');
          $$('.evtile', grid).forEach(function (x) { x.className = 'evtile'; }); c.className = 'evtile on';
          view.innerHTML = ''; view.appendChild(evidenceCard(id));
        };
        grid.appendChild(c);
      });
      body.appendChild(grid); body.appendChild(view);
    }
    function drawNotebook() {
      var ids = Engine.notebookIds();
      if (!ids.length) { body.appendChild(el('<p class="empty">' + esc(t('inv.empty_nb')) + '</p>')); return; }
      var list = el('<div class="nblist"></div>');
      ids.forEach(function (id) {
        var e = Story.notebook[id]; if (!e) return;
        var c = el('<div class="nbcard"><h4></h4><ul></ul></div>');
        $('h4', c).textContent = L(e.title);
        var lines = e.lines ? (e.lines[I18N.get()] || e.lines.my || e.lines.en || []) : [];
        lines.forEach(function (ln) { var li = document.createElement('li'); li.textContent = ln; $('ul', c).appendChild(li); });
        list.appendChild(c);
      });
      body.appendChild(list);
    }
    function drawNotes() {
      var r = API.listNotes(), notes = r.ok ? r.notes : [], active = null;
      var left = el('<div class="noteside"><button class="btn red wide" data-i18n="inv.new"></button><div class="nlist"></div></div>');
      var ed = el('<div class="noteedit"><input class="in" maxlength="100" data-i18n-ph="inv.note_title"><textarea maxlength="5000" data-i18n-ph="inv.note_body"></textarea><div class="row"><button class="btn red sv" data-i18n="inv.save"></button><button class="btn dl" data-i18n="inv.delete"></button><span class="saved"></span></div></div>');
      body.appendChild(left); body.appendChild(ed); I18N.apply(body);
      var nl = $('.nlist', left), ti = $('input', ed), ta = $('textarea', ed);
      function pick(n) { active = n; ti.value = n ? n.title : ''; ta.value = n ? n.content : ''; $('.saved', ed).textContent = ''; drawList(); }
      function drawList() {
        nl.innerHTML = '';
        if (!notes.length) nl.appendChild(el('<p class="empty small">' + esc(t('inv.no_notes')) + '</p>'));
        notes.forEach(function (n) {
          var c = el('<div class="nitem' + (active && active.id === n.id ? ' on' : '') + '"><b></b><small></small></div>');
          $('b', c).textContent = n.title || '—'; $('small', c).textContent = n.updated;
          c.onclick = function () { click('page'); pick(n); }; nl.appendChild(c);
        });
      }
      $('.btn.red', left).onclick = function () { click(); pick(null); ti.focus(); };
      $('.sv', ed).onclick = function () {
        if (!ti.value.trim() && !ta.value.trim()) return;
        var r2 = API.saveNote(active ? active.id : 0, ti.value, ta.value);
        if (!r2.ok) { toast(t(r2.error)); return; }
        click(); var rl = API.listNotes(); notes = rl.ok ? rl.notes : notes;
        active = notes.filter(function (n) { return n.id === r2.id; })[0] || null; drawList(); $('.saved', ed).textContent = t('inv.saved');
      };
      $('.dl', ed).onclick = function () {
        if (!active) { pick(null); return; }
        API.deleteNote(active.id); click(); var rl = API.listNotes(); notes = rl.ok ? rl.notes : []; pick(null);
      };
      pick(null);
    }
    draw();
    return h;
  }

  return {
    init: init, el: el, esc: esc, $: $, $$: $$, show: show, rerender: rerender, screenName: screenName, toast: toast,
    overlay: overlay, modal: modal, key: key, hasOverlay: hasOverlay, closeAll: closeAllOverlays,
    login: login, menu: menu, cases: cases, pause: pause, settings: settingsPanel, inventory: inventory,
    evidenceCard: evidenceCard, click: click, isUnlocked: isUnlocked,
    stageEl: function () { return stage; }, screenEl: function () { return screen; },
    redrawSettings: function () { if (settingsPanel.current && settingsPanel.current.redraw) settingsPanel.current.redraw(); }
  };
})();

/** Settings: load/save per player, apply to the page and to Java (volume, fullscreen). */
var Settings = {
  load: function () {
    var s = {}, k, r = API.getSettings(), saved = {};
    if (r.ok && r.settings) { try { saved = JSON.parse(r.settings); } catch (e) {} }
    for (k in G.defaults) s[k] = saved[k] != null ? saved[k] : G.defaults[k];
    G.settings = s;
    I18N.set(s.lang); API.setLang(s.lang);
    this.apply(true);
  },
  /** Used before login: only a language preference exists. */
  loadDefaults: function () {
    G.settings = {}; for (var k in G.defaults) G.settings[k] = G.defaults[k];
    G.settings.lang = API.getLang(); I18N.set(G.settings.lang); this.apply(false);
  },
  apply: function (fullscreen) {
    var s = G.settings, st = UI.stageEl();
    st.className = 'ts-' + s.size + (s.hints ? '' : ' nohints');
    API.volumes(s.master, s.music, s.sfx);
    if (fullscreen !== false) API.setFullscreen(!!s.full);
  },
  save: function () {
    G.settings.lang = I18N.get();
    this.apply(true);
    if (G.me) API.saveSettings(G.settings);
  },
  setLang: function (l) {
    I18N.set(l); G.settings.lang = l; API.setLang(l);
    if (G.me) API.saveSettings(G.settings);
    UI.rerender(); UI.redrawSettings();
  }
};
